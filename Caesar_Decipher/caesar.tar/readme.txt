EE 355 Caesar Decipher Programming Assignment

Name:

Email Address: 

NOTE: You can delete the questions, we only need your responses.

NOTE: It is helpful if you write at most 80 characters per line,
and avoid including special characters, so we can read your responses.

:

=============================== Questions ===================================

1. Using your "crack" program, decipher the following intercepted message:
             Ljnbja'b bnlanc bjujm anlryn

:

2. Read the section "Examples and Caveat" on the assignment webpage.
Find an English term, phrase, or sentence other than 
"Rhythm & Blues" that the crack program cannot handle correctly. It should
contain at least 8 letters. Please avoid place names / proper names like
"Tarzana" or "Ziggie".

English message :

Result of encoding and then cracking it :

3. (Optional) Did you add any extra functions to caesarlib.h and 
caesarlib.cpp for your convenience? If so, briefly explain.

:

================================ Remarks ====================================

Filling in anything here is OPTIONAL.

Approximately how long did you spend on this assignment?

Do you have any feedback about this assignment?

:

Were there any specific problems you encountered? This is especially useful to
know if you turned it in incomplete.

:

Do you have any other remarks?

:
