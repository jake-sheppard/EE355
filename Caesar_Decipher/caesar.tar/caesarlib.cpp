/* 
caesarlib.cpp

Author:

Short description of this file:
*/

#include <fstream>
#include <iostream>
#include "caesarlib.h"

using namespace std;

// is this char an English letter?
bool is_letter(char ch) {
   return false; // DELETE this stub and fill in the function body
}

// return shifted image of ch (if ch not letter, don't shift)
// assumes 0 <= steps < 26
char image(char ch, int steps) {
   return ' '; // DELETE this stub and fill in the function body
}

// shift all characters in this file and print it to cout
// return 1 if error (file couldn't be opened), 0 if no error
int print_file_image(const char filename[], int steps) {
   return 1; // DELETE this stub and fill in the function body
}

