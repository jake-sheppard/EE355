#include <iostream>
#include <cstdlib>
#include <deque>
#include "board.h"
#include "puzzle_heur.h"
#include "puzzle_solver.h"

int main(int argc, char *argv[])
{
  if(argc < 5){
    cerr << "Usage: ./puzzle size initMoves seed heur" << endl;
    return 1;
  }

  int size, initMoves, seed, heur;

  size = atoi(argv[1]);
  initMoves = atoi(argv[2]);
  seed = atoi(argv[3]);
  heur = atoi(argv[4]);

  Board b(size,initMoves,seed);

  PuzzleHeuristic* ph;
  if(heur == 0){
    ph = new PuzzleBFSHeuristic;
  }
  else if(heur == 1){
    ph = new PuzzleOutOfPlaceHeuristic;
  }
  else {
    ph = new PuzzleManhattanHeuristic;
  }

  //*********** Implement the gameplay here






  return 0;
}
